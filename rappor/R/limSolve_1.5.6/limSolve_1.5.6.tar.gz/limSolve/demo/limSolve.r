
# lsei
example(lsei)

# parsimonious (simplest) solution of mink diet problem
example(Minkdiet)
example(varsample)

# Chemtax by lsei
example(Chemtax)

# E.coli core metabolism
example(E_coli)
