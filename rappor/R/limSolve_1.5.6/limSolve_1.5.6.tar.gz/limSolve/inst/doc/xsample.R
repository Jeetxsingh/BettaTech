### R code from vignette source 'xsample.Rnw'
### Encoding: UTF-8

###################################################
### code chunk number 1: preliminaries
###################################################
library("limSolve")
options(prompt = "> ")



